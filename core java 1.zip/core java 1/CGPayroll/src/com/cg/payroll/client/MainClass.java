package com.cg.payroll.client;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.doaservices.AssociateDAO;
import com.cg.payroll.doaservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidEmailIdException;
import com.cg.payroll.serilization.PayrollSerilize;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException, InvalidEmailIdException {
		/*Associate [] associates=new Associate[5];
	 associates[0]=new Associate(111, 10000, "nikita", "deshmukh","cse", "analyst", "escoiu34", "niki@gmail.com", new Salary(120000,300000,100000),new BankDetails(123234,123,"hdfc"));
	 associates[1]=new Associate(111, 100000, "nikita", "deshmukh","cse", "analyst", "escoiu34", "niki@gmail.com", new Salary(1000,3000,1000),new BankDetails(123234,123,"hdfc"));
	 associates[2]=new Associate(111, 10000, "nikita", "deshmukh","cse", "analyst", "escoiu34", "niki@gmail.com", new Salary(1000,3000,1000),new BankDetails(123234,123,"hdfc"));
	 associates[3]=new Associate(111, 10000, "nikita", "deshmukh","cse", "analyst", "escoiu34", "niki@gmail.com", new Salary(1000,3000,1000),new BankDetails(123234,123,"hdfc"));
	 associates[4]=new Associate(111, 10000, "nikita", "deshmukh","cse", "analyst", "escoiu34", "niki@gmail.com", new Salary(1000,3000,1000),new BankDetails(123234,123,"hdfc"));

		for (Associate associate : associates) {
			if((associate.getSalary().getBasicSalary()>=20000) && (associate.getBankDetails().getBankname()=="hdfc"))
			System.out.println(associate.getFirstname()+" "+associate.getLastname());*/
		/*System.out.println("**********Menu***********");
		System.out.println("1)save");
		System.out.println("2)update");*/

		try {
			PayrollServices payrollServices=new PayrollServicesImpl();
			int associateID=payrollServices.acceptAssociateDetails(5000, "nikita", "deshmukh", "asf", "analyst", "vfgf222", "nikita@gmail.com", 50000,1000,1000, 123346578, 3333, "hdfc");
			System.out.println("AssociateID="+associateID);
			Associate associate=payrollServices.getAssociateDetails(associateID);
			int associateID1=payrollServices.acceptAssociateDetails(1000, "mayur", "deshmukh", "comp", "analyst", "vfgf222", "nikita@gmail.com", 50000,1000,1000, 123346578, 3333, "hdfc");
			Associate associate1=payrollServices.getAssociateDetails(associateID1);
			System.out.println("AssociateID="+associateID1);
			//System.out.println(associate.toString());
			int salary=payrollServices.calculateNetSalary(associateID);
			System.out.println(salary);
			AssociateDAO associateDAO=new AssociateDAOImpl();
			System.out.println(associateDAO.findAll());
			//File file=new File("D:\\abc1.txt");
			//PayrollSerilize.doSerilization(file);
			//PayrollSerilize.doDeSerilization(file);
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
	}

}


