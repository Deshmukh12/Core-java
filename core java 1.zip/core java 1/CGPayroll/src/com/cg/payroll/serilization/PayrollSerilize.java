package com.cg.payroll.serilization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollUtil;



public class PayrollSerilize {
	public static HashMap<Integer, Associate>associates=PayrollUtil.associates;
	public static void doSerilization(File file) throws FileNotFoundException, IOException {
		try(ObjectOutputStream deStream=new ObjectOutputStream(new FileOutputStream(file))){
			deStream.writeObject(associates);
			System.out.println("associate obj written on :"+file.getAbsolutePath());
		}
	}

	public static void doDeSerilization(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
		try(ObjectInputStream dInputStream=new ObjectInputStream(new FileInputStream(file))){
			 associates=(HashMap<Integer, Associate>)dInputStream.readObject();
		//	System.out.println("associate obj written on :"+file.getAbsolutePath());
			System.out.println(associates.toString());
		}
}
}