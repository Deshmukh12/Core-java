package com.cg.payroll.doaservices;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollUtil;
public class AssociateDAOImpl implements AssociateDAO{
	@Override
	public Associate save(Associate associate) {
		/*associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());
		PayrollUtil.associates[PayrollUtil.getASSOCIATE_IDX()]=associate;
		return associate;*/
		associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());
				PayrollUtil.associates.put(associate.getAssociateID(),associate);
		return associate;
	}
	@Override
	public boolean update(Associate associate) {
		PayrollUtil.associates.put(associate.getAssociateID(),associate);
		return true;
	}
	@Override
	public Associate findOne(int associateID) {
		/*for (Associate associate : PayrollUtil.associates) 
			if(associate!=null&& associate.getAssociateID()==associateID)
				return associate;
		return null;*///using array we require to used foreach
		return PayrollUtil.associates.get(associateID);
	}
	@Override
	public List<Associate> findAll() {
		/*ArrayList<Associate>associatesList=new ArrayList<>(PayrollUtil.associates.values());
		return associatesList;*/
		
		return new ArrayList<>(PayrollUtil.associates.values());
		/*ArrayList<Associate>associatesList=new ArrayList<>();//creating empty list
		Set<Integer>keySet=PayrollUtil.associates.keySet();
		for (Integer integer : keySet) {
			associatesList.add(PayrollUtil.associates.get(key);//second way
		}*/
	
	}
}
