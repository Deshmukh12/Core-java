package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.doaservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;

	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDao);
	}

	@Before
	public void setUpTestMockData() {
		Associate associate1=new Associate(101,10000,"nikita", "deshmukh", "asf", "analyst", "vfgf222", "nikita@gmail.com", 
				new Salary(50000,1000,1000),new BankDetails(123346578, 3333, "hdfc"));

		Associate associate2=new Associate(102,10000, "mayur", "deshmukh", "comp", "analyst", "vfgf222", "nikita@gmail.com", 
				new Salary(50000,1000,1000),new BankDetails(123346578, 3333, "hdfc"));

		Associate associate3=new Associate(123,10000,"nikita", "deshmukh", "asf", "analyst", "vfgf222", "nikita@gmail.com", 
				new Salary(50000,1000,1000),new BankDetails(123346578, 3333, "hdfc"));

		ArrayList<Associate>associateList=new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);
		EasyMock.replay(mockAssociateDao);

	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateID()throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}

	@Test
	public void testGetAssociateDataForValidAssociateID()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(102,10000, "mayur", "deshmukh", "comp", "analyst", "vfgf222", "nikita@gmail.com", 
				new Salary(50000,1000,1000),new BankDetails(123346578, 3333, "hdfc"));
		Associate actualAssociate=payrollServices.getAssociateDetails(102);
		EasyMock.verify(mockAssociateDao.findOne(102));
		assertEquals(expectedAssociate, actualAssociate);
	}	
	
	@Before
	public void tearDownTestMockData() {
		 EasyMock.resetToDefault(mockAssociateDao);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollServices=null;
	}
}