package com.cg.inheritance.client;

import com.cg.inheritance.beans.Car;
import com.cg.inheritance.beans.Truck;
import com.cg.inheritance.beans.Vehical;

public class MainClass {

	public static void main(String[] args) {
		Vehical v;

        
        v=new Truck("tata","tt42",2007,12.99);
        Truck t=(Truck)v;
        v.speed();
        t.getTonnage();
		System.out.println(v.getMake()+" "+v.getModel()+" "+v.getYear()+" "+t.getTonnage());
    
       
      v=new Car("tata motors","t42",2007,100,40,2);
      Car c=(Car)v;
      v.speed();
      c.getSpeed1();
		System.out.println(v.getMake()+" "+v.getModel()+" "+v.getYear()+" "+c.getSpeed1());
  
	}
	

}
