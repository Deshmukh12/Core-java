package com.cg.inheritance.beans;
public final class Truck extends Vehical{
	private double tonnage;
	public Truck() {
		super();
	}
	public Truck(String make, String model, int year,double tonnage) {
		super(make, model, year);	
		this.tonnage=tonnage;
	}
	public Truck(double tonnage) {
		super();
		this.tonnage = tonnage;
	}
	public double getTonnage() {
		return tonnage;
	}
	public void setTonnage(double tonnage) {
		this.tonnage = tonnage;
	}
	public void speed() {
		System.out.println("tonnage:"+tonnage);
	}
}
