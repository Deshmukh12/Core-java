package com.cg.inheritance.beans;
public abstract class Vehical {
	private String make;
	private String model;
	private int year,vehicalid;
	public Vehical() {
		super();
	}
   public Vehical(String make, String model, int year) {
		super();
		this.make = make;
		this.model = model;
		this.year = year;
	}
   public Vehical(String make, String model, int year, int vehicalid) {
		super();
		this.make = make;
		this.model = model;
		this.year = year;
		this.vehicalid = vehicalid;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getVehicalid() {
		return vehicalid;
	}
	public void setVehicalid(int vehicalid) {
		this.vehicalid = vehicalid;
	}
	public abstract void speed();
	
}
