package com.cg.inheritance.beans;

public final class Car extends Vehical{
	private String owner;
	private int speed1,distance,time;
	public Car() {
		super();
	}
public Car(String make, String model, int year,int distance,int speed1,int time) {
		super(make, model, year);
		this.distance=distance;
		this.speed1=speed1;
		this.time=time;
	}
	
	
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public int getSpeed1() {
		return speed1;
	}
	public void setSpeed1(int speed1) {
		this.speed1 = speed1;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public void speed() {
		System.out.println("in Car @@");
		speed1=distance/time;
		this.setSpeed1(speed1);
	}
}
