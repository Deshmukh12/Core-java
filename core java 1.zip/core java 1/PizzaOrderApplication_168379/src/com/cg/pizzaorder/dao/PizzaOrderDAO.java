package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO{
	public static Map<Integer, PizzaOrder>pizzaEntry=new HashMap<>();
	public static   Map<Integer, Customer>customerEntry=new HashMap<>();
	public static int CUSTOMER_ID_COUNTER=100;
	public static int ORDER_ID_COUNTER=100;
  public static int getCUSTOMER_ID_COUNTER() {
		return ++CUSTOMER_ID_COUNTER;
	}
public static int getORDER_ID_COUNTER() {
	return ++ORDER_ID_COUNTER;
}
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
         

		return 0;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		// TODO Auto-generated method stub
		return null;
	}

}
