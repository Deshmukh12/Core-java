package com.cg.pizzaorder.ui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {
	public static void main(String[] args) throws PizzaException {
	System.out.println("1)Place Order");
	System.out.println("2)Display Order");
	System.out.println("3)Exit");
	IPizzaOrderService iPizzaOrderService=new PizzaOrderService();
	Scanner s=new Scanner(System.in);
	System.out.println("Enter your choice:");
	int ch=s.nextInt();
	do {
		switch(ch) {
		case 1:System.out.println("Enter the name of the customer:");
		String custName=s.next();
		    System.out.println("Enter customer address:");
		    String custAdd=s.next();
		    System.out.println("Enter customer phone number:");
		    int custMob=s.nextInt();
		    System.out.println("Type of Pizza Topping preferred:");
		    String pizzaTopp=s.next();
		    System.out.println("Order Date:");
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
		    Date date = new Date();  
		    System.out.println(formatter.format(date));  
		    
		case 2: System.out.println("Enter the order id:");
		int orderId=s.nextInt();
		//IPizzaOrderService iPizzaOrderService2=iPizzaOrderService.getOrderDetails(orderId);
			System.out.println(" "+iPizzaOrderService.getOrderDetails(orderId));
			
		//case 3:exit(1);	
		}
	}while(ch!=0);
	}

}
