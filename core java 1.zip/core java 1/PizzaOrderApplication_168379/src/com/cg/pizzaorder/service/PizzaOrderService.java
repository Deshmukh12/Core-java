package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.InvalidMoblieNumberException;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService{
private IPizzaOrderDAO iPizzaOrderDAO=new PizzaOrderDAO();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		Customer customer2=new Customer(custName, address, phone, new PizzaOrder(orderId, totalPrice));
		if(customer2.getPhone().length()<10)throw new InvalidMoblieNumberException();
		return 0;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void calculatePizzaTopping(String pizzaTopping) {
		int basePizzaPrice=350, totalPrice;
		
		
	}

	

	
	

}
