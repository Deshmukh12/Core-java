package com.cg.pizzaorder.test;
import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.InvalidMoblieNumberException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;
public class PizzaOrderServicesTest {
	static IPizzaOrderService iPizzaOrderService;
	@BeforeClass
    public static void setUpTestEnv() {
        iPizzaOrderService=new PizzaOrderService();
    }
	@Test
	 public void testMobileNumberData()throws InvalidMoblieNumberException{
		  int expectedorderId=101;
		  
	 }
@AfterClass
public static void tearDownTestEnv() {
	iPizzaOrderService=null;
}
}
