package com.cg.pizzaorder.ui;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.InvalidMoblieNumberException;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;
public class Client {
	public static void main(String[] args) throws PizzaException, InvalidMoblieNumberException {
		Scanner  s=new Scanner(System.in);
		IPizzaOrderService iPizzaOrderService=new PizzaOrderService();
		int ch;
		System.out.println ("1) Place Order \n");
		System.out.println("2) Display Order \n");
		System.out.println(" 3) Exit");
		do {
			System.out.println("Enter your choice:");
			ch=s.nextInt();
			switch(ch){

			case 1:System.out.println("Enter your details: Name,Address,PhoneNo,TypeofPizzaTopping");
			String custName=s.next();
			String address=s.next();
			String phone=s.next();
			String pizzaTopping=s.next();
			double totalPrice=(double)iPizzaOrderService.priceCalculate(pizzaTopping);        
			int orderId=iPizzaOrderService.placeOrder(new Customer(custName, address, phone), new PizzaOrder(totalPrice));
			System.out.println("Pizza order successfully placed with Order Id :"+orderId+ "for RS:"+totalPrice);
			 System.out.println("Order Date:\n");
			    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
			    Date date = new Date();  
			    System.out.println(formatter.format(date));  
			    
			break;                  

			case 2:System.out.println("Enter Order Id:");
			int orderid=s.nextInt();      
			PizzaOrder pizza=iPizzaOrderService.getOrderDetails(orderid);                 
			System.out.println(pizza.toString());
			break;

			case 3: System.exit(0);
			break;
			}
		}while(ch<=3);          

	}
}
