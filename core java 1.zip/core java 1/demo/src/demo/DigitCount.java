package demo;

public class DigitCount {
	public static void main(String[] str){
        int num=0, one=0, two=0, three=0;
        int arr[] = new int[]{2322,143, 343, 1, 3, 5,6, 98,65,342, 74};

        for(int n=0; n<arr.length; n++){
            num =arr[n];
            if(num>0 && num<10)
                one++;

            if(num>9 && num<100)
                two++;

            if(num>99 && num<999)
                three++;
        }

        System.out.println("Number of one digit number : " +one);
        System.out.println("Number of two digit number : " +two);
        System.out.println("Number of three digit number : " +three);
    }
}
