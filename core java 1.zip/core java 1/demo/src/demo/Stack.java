package demo;


public class Stack{    
        private int size;
        private int[] stackArr;
        private int top = -1;
        
        public Stack(int size) {
            this.size = size;
            stackArr = new int[size];
        }
        
        public void push(int i) {
            top++;
            System.out.println("Pushing"+top);
            stackArr[top] = i;
        }
                
        public int pop() {
            int i = stackArr[top];
            
            System.out.println("Popping"+top);
            top--;
            return i;
        }
        
        public boolean isFull() {
            return (top == size-1);
        }
        
        public boolean isEmpty() {
            return (top == -1);
        }
  //  }


//public class StackClient {
    public static void main(String[] args) {
        Stack tns = new Stack(3);

        if(!tns.isFull())
            tns.push(4);
        if(!tns.isFull())
            tns.push(5);
        if(!tns.isFull())
            tns.push(3);
        if(!tns.isFull())
            tns.push(6);
        else 
            System.out.println("Stack full, cannot push element");

        if(!tns.isEmpty())
            tns.pop();
        if(!tns.isEmpty())
            tns.pop();
        if(!tns.isEmpty())
            tns.pop();
        if(!tns.isEmpty())
            tns.pop();
        else 
            System.out.println("Stack empty, cannot pop element");
    }

}


