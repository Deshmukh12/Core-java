package demo;

public class Pattern7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char i=1;i<=5;i++)
		{
			for(char j=1;j<=i;j++)
			{
				System.out.print(""+j);
			}
			System.out.println("");
		}
	}

}
