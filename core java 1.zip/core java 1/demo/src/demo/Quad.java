package demo;

public class Quad {

	public static void main(String[] args) {
		int a=2,b=6,c=4;
		double ss=Math.sqrt(b*b-4*a*c);
		double r1=(-b+ss)/(2*a);
		double r2=(-b-ss)/(2*a);
		System.out.println("thr roots are "+r1+" "+r2+" ");
	}

}
