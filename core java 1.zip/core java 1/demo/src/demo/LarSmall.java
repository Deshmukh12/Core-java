package demo;

public class LarSmall {
	 public static void main(String[] args) {
	        int count[] = new int[10]; 
	        int num =3605;
	        String str = Integer.toString(num); 
	        for(int i=0; i < str.length(); i++) 
	            count[str.charAt(i)-'0']++; 
	        int result = 0, multiplier = 1; 
	        for (int i = 0; i <= 9; i++)    { 
	            while (count[i] > 0) { 
	                result = result + (i * multiplier); 
	                count[i]--; 
	                multiplier = multiplier * 10; 
	            } 
	        } 
	        System.out.println(result+"largest no");

	        int[] freq = new int[10]; 
	        while (num > 0) { 
	            int d = num % 10; 
	            freq[d]++; 
	            num = num / 10;
	        }
	        for (int i = 1 ; i <= 9 ; i++) { 
	            if (freq[i] != 0) { 
	                result = i; 
	                freq[i]--; 
	                break; 
	            } 
	        } 
	        for (int i = 0 ; i <= 9 ; i++)
	            while (freq[i]-- != 0) 
	                result = result * 10 + i;
	        System.out.println(result+"smallest no");

	    }
}
