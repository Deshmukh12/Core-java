package demo;

public class Oeppalin {
	public static void main(String[] args) {

        System.out.println("Armstrong Numbers 1 to 500 ");
        for(int i=1;i<=500;i++)
        {
            if(Armstrong(i)==true) 
                System.out.println(i+" ");
        }

        System.out.println("\nPalindrome Numbers 1 to 500 ");
        for(int i=1;i<=500;i++)
        {
            if(Palindrome(i)==true) 
                System.out.println(i+" ");
        }

        System.out.println("\nPrime  Numbers 1 to 500 ");

        for(int i=1;i<=500;i++){
            if(Prime(i)==true) 
                System.out.println(i+" ");
        }

        System.out.println("Even Numbers 1 to 10 ");
        for(int i=1;i<=10;i++)
        {
            if(Even(i)==true) 
                System.out.println(i+" ");

        }
        System.out.println("Odd Numbers 1 to 10 ");
        for(int i=1;i<=10;i++)
        {
            if(Odd(i)==true) 
                System.out.println(i+" ");

        }

    }
    public static boolean Armstrong(int n) {

        int a,x,t,s=0;
        x=n;
        while(n>0)
        {
            a=n%10;
            t=a*a*a;
            n=n/10;
            s=s+t;
        }
        if(s==x) {
            return true;
        }
        else
            return false;

    }
    public static boolean Palindrome(int n) {

        int a,x,s=0;
        x=n;
        while(n>0)
        {
            a=n%10;
            s=s*10+a;
            n=n/10;
        }
        if(s==x) {
            return true;
        }
        else
            return false;

    }
    public static boolean Prime(int n) {

        int n1,i,c=0;

        for(i=1;i<=n;i++)
            if(n%i==0)
            {   
                c++;
            }
        if(c==2) {
            return true;
        }
        else

            return false;

    }
    public static boolean Even(int n) {

        int n1,i;

        for(i=1;i<=n;i++) {
            if(n%2==0)
                return true;

            else
                return false;

        }
        return false;
    }
    public static boolean Odd(int n) {

        int n1,i;

        for(i=1;i<=n;i++) {
            if(n%2!=0)
                return true;

            else
                return false;

        }
        return false;
    }
}
