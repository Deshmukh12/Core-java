package demo;

public class Ass {

}
