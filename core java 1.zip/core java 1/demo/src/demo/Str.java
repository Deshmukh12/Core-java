package demo;

public class Str {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s=new String("hiii");
System.out.println(s);
String s3="HIII";
String s8=s3.replaceAll("HIII", "byeeee");
int a=12;
String s6=String.valueOf(a);
String s5="   Hello  ";
String s4="HIII"+"GUYS";
String s2=s.concat("everyone");
System.out.println(s2);
System.out.println(s.equals(s3));
System.out.println(s.equalsIgnoreCase(s3));
System.out.println(s==s3);
System.out.println(s4);
System.out.println(s3.substring(0, 1));
System.out.println(s3.toLowerCase());
System.out.println(s.toUpperCase());
System.out.println(s5.trim());
System.out.println(s3.startsWith("H"));
System.out.println(s3.endsWith("o"));
System.out.println(s5.charAt(3));
System.out.println(s3.length());
System.out.println(s6);
System.out.println(s8);

}
}
