package demo;

public class Thirdl {
	 public static void main(String[] args) {    
	        int a[]= {7,2,3,5,6};
	        int total=a.length,temp;
	        for (int i = 0; i < total; i++)   
	        {  
	            for (int j = i + 1; j < total; j++)   
	            {  
	                if (a[i] > a[j])   
	                {  
	                    temp = a[i];  
	                    a[i] = a[j];  
	                    a[j] = temp;  
	                }  
	            }  
	        }  
	        System.out.println(a[total-3]+"");  
	    }  
}
