package demo;

public class Occurance {

	public static void main(String[] args) {
		int a[]= {1,4,1,2,2,2};
		int res=0;
		int n1=0,n2=0,n3=0;
		int n=a.length;
			for(int i=0;i<n;i++) {
				if(a[i]==1)
			  n1++;
				else if(a[i]==2)
					n2++;
				else if(a[i]==4)
					n3++;
			
			}
		System.out.println("occ of 1="+n1+"occu of 2 is"+n2+"occu of 4 is "+n3+" ");
			}
				
	}


