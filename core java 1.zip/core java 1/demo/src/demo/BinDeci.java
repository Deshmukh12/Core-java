package demo;

public class BinDeci {
	 public static void main(String[] args){  
	        int n=5,n1=01, a;
	        String x = "";     
	        while(n > 0)
	        {
	            a = n % 2;
	            x = x + "" + a;
	            n = n / 2;
	        }
	        System.out.println("Binary number:"+x);
	    
	        int decimal = 0,binaryNumber=101;
	        int p = 0;
	        while(true){
	          if(binaryNumber == 0){
	            break;          
	           }
	          else {
	              int temp = binaryNumber%10;
	              decimal += temp*Math.pow(2, p);
	              binaryNumber = binaryNumber/10;
	              p++;
	           }
	        }
	        System.out.println("decimal number:"+decimal);        
	    }
}
