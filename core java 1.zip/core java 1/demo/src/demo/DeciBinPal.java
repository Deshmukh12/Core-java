package demo;

public class DeciBinPal {
	 public static void main(String[] args) {        
	        int no=12, a,rem,rev=0,org;;
	        String x = "";     
	        while(no > 0)
	        {
	            a = no % 2;
	            x = x + "" + a;
	            no = no / 2;
	        }
	        System.out.println("Binary number:"+x);                            
	        int n=121;
	        org=n;
	        while(n!=0){
	            rem=n%10;
	            rev=rev*10+rem;
	            n=n/10;         
	        }
	        if(org==rev)
	        System.out.println(org+"  palindrom Number");
	        else
	        System.out.println(org+" not palindrom Number");
	    }
}
