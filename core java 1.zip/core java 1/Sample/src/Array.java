
public class Array {

	public static void main(String[] args) {
	int [][][] numlist=new int[2][5][3];
	    for(int i=0;i<numlist.length;i++)  {  
	    	for(int j=0;j<numlist[i].length;j++){
	    		for(int k=0;k<numlist[i][j].length;k++){
	    			System.out.print(" "+numlist[i][j][k]);
	    		}
	    	}
	    }
	    	
	}

}
