
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
  Abc  abc1=new Abc(100,111);
  abc1.display();
  Abc  abc2=new Abc(106,111);
  abc2.display();
	}

}
