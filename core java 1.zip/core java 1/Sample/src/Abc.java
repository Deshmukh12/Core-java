
public class Abc {
	 private int id,id2;
	 private static int empid;
	
	 public Abc(int id,int id2) {
		super();
		this.id = id;
		this.id2=id2;
		id++;id2++;empid++;
	}
	
public void display()
{
System.out.println("empi is "+empid+" "+id+" "+id2+" ");	
}
	 
}


