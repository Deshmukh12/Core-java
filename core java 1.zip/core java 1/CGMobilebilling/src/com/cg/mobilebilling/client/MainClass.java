package com.cg.mobilebilling.client;

import com.cg.mobilebilling.beans.Customer;

public class MainClass {

	public static void main(String[] args) {
		Customer cust=new Customer(111,576875844,263545,12/1/1999,"nikita","deshmukh","niki@gmail.com");
		//System.out.println(+customerID. getCustomerID());

	}

}
