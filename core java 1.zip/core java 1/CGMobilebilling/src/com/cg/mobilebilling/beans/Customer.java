package com.cg.mobilebilling.beans;

public class Customer {
	private int customerID,adharNo,pancardNo,dateOfBirth;
	private String firstName,lastName,emailId;
	PostPaidAccount accounts=new PostPaidAccount();
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public Customer(int customerID, int adharNo, int pancardNo, int dateOfBirth, String firstName, String lastName,
			String emailId) {
		super();
		this.customerID = customerID;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public int getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(int pancardNo) {
		this.pancardNo = pancardNo;
	}
	public int getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(int dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}
