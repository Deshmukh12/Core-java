package com.cg.mobilebilling.beans;

public class PostPaidAccount {
	private int mobileNo;
	
	Bill [] bills=new Bill[5];
	public PostPaidAccount() {
		// TODO Auto-generated constructor stub
	}
	public PostPaidAccount(int mobileNo) {
		super();
		this.mobileNo = mobileNo;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

}
