
public class Abc {

		   public static void main(String[] args) { 
//			   StringBuilder s = new StringBuilder("123456789"); 
//			   s.delete(0,3).delete(1,3).delete(2,5).insert(1, "24");  //output is 4247
//			            System.out.println(s); 
			 //////////////////////////////////////////////////////////
//			   
//			   int i; 
//			   public static void main(String[] args) { 
//			   int i; //1
//               private int a = 1; //2
//               protected int b = 1; //3                  //compile time error at 2,3,4,5.
//               public int c = 1; //4
//               System.out.println(a+b+c); //5
			   
			   ///////////////////////////////////////////////
			   
//			   String k ="big "; 
//			      k.concat("crowded ");                  //output:big city
//			      k += "city";
//			      System.out.println(k);
			       } 
}
