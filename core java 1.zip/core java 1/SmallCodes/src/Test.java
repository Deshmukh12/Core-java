import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.Iterator;
//import java.util.LinkedList;
//import java.util.Set;
//import java.util.TreeSet;
//
////public class Test {
////    static String str;
////       public static void main(String[] args) {
////        String s;
////        if(str=="abc")                                                                      //Compile error, s not initialised.
////           s = str+10;
////        System.out.println(str);
////        System.out.print(s);
////       }
////}
//
//////////////////////////////////////////////////////////
//
////public class Test{ 
////  public static void main(String args[]) {
////    B b = new B();
////  }
////}
////class A {
////  A() {
////    System.out.print("A");                                               //o/p:AB
////  }
////}
////class B extends A{
////  B() {
////    System.out.print("B");
////  }
////}
//
////////////////////////////////////////////////////////////////
//
//// public class Test {
////      public static void main(String [] args) {
////         short a=0, b=0, c;
////         a=1;
////         b=2;                                                     //o/p:3
////         c=(short) (a+b);
////         System.out.println(c);
////      }
////  }
//
////////////////////////////////////////////////////////
//
//// public class Test {
////      public static void main(String [] args) {
////         short a, b, c=0;
////         a=1;
////         b=2;                                                     //o/p:compilation error
////         c=(a+b);
////         System.out.println(c);
////      }
////  }
//////////////////////////////////////////////
////import java.util.ArrayList;
////import java.util.List;
////public class Test {     
////      public static void main(String[] args) {
////           List<String> list = new ArrayList<>();
////           list.add("English");
////           list.add("Hindi");
////           list.add("Kannada");
////           list.add("Marathi");                                                             //MarathiTamil
////           list.add("Tamil");
////           list.add("Telugu");
////           list.add(2,"Oriya");
////           System.out.print(list.get(4));
////           list.remove(3);
////           System.out.print(list.get(4));
////      }
////}
/////////////////////////////////////////////
////class Test{
////public static Collection get() { 
////        Collection sorted = new LinkedList(); 
////         sorted.add("B"); sorted.add("C"); sorted.add("A"); 
////          return sorted; 
////} 
////public static void main(String[] args) {                           //B, C, A, 
////           Collection list = get();
////        for (Object obj: list) { 
////                    System.out.print(obj + ", "); 
////          } 
//// } 
////
////}
//
//
//////////////////////////////////////////////
////class Test{
////public static void main(String args[]){
////ArrayList<String> list= new ArrayList<>();
////list.add("SE");
////list.add("EE");
////list.add("ME");
////list.add("SE");
////list.add("EE");                                      Values are : [EE, ME, SE, EE]
////
////list.remove("SE");
////System.out.println("Values are : "+ list);
////}
////}
/////////////////////////////////
////public class Test {
////public static void main(String... args) {
////
////Set s = new TreeSet();
//// s.add("7");
//// s.add(9);                                                                   //runtime exception
//// Iterator itr = s.iterator();
//// while (itr.hasNext())
//// System.out.print(itr.next() + " ");
////}
////}
///////////////////////////////////////
//import java.util.*;
// public class Test {
// public static void main(String[] args) {
//	 Set set = new TreeSet();
//	 set.add(new Integer(2));                                         [1,2]
// set.add(new Integer(1));
// System.out.println(set);
// }
//}
///////////////////
//public class Test{
//public static void main(String[] args) {
// ArrayList<String> strings = new ArrayList<String>();
// strings.add("aAaA");
// strings.add("AaA");
// strings.add("aAa");
// strings.add("AAaa");                                                                                       //AAaa AaA aAa aAaA 
// Collections.sort(strings);
// for (String s : strings) { System.out.print(s + " "); }
// }
//}
//////////////////////////
public class Test{
	public static void main(String[] ar) {
		/*int a=Integer.parseInt(ar[0]);
		int b=Integer.parseInt(ar[1]);
		System.out.println(a+b); //if it is command line then it gets op when in case of string as ip it gets numberformat exception
	}*/
		
		
//		try {
//			if(ar.length==0) throw new Exception();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//		System.out.println("done");
//		}                                                        //op:done fin
//		
//		
//		finally {
//			System.out.println("fin");
//		}
//		
//		
//		
//		
//	}
//		
		///////////////////////////////////////////////////
//java.util.List<Integer>listint=Arrays.asList(10,20,30,40,50,60);
//System.out.println(listint.stream().reduce((prev,current)->prev+current));         //Optional[210]
 
		///////////////////////////
	

	}
		
}