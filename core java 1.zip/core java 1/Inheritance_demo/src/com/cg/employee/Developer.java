package com.cg.employee;

public class Developer extends Pemployee {
private int intensive,noofprojects;

public Developer() {
	super();
}
public Developer(int employeeid, int basicSalary, String firstname, String lastname,int noofprojects) {
	super(employeeid, basicSalary, firstname, lastname);
	this.noofprojects=noofprojects;
}
public Developer(int intensive, int noofprojects) {
	super();
	this.intensive = intensive;
	this.noofprojects = noofprojects;
}
public int getIntensive() {
	return intensive;
}
public void setIntensive(int intensive) {
	this.intensive = intensive;
}
public int getNoofprojects() {
	return noofprojects;
}
public void setNoofprojects(int noofprojects) {
	this.noofprojects = noofprojects;
}
public void doProject() {
	System.out.println("project has completed");
}
@Override
public void calculateSalary() {
intensive=noofprojects*1000;
	super.calculateSalary();
	this.setTotalSalary(getTotalSalary()+intensive);
}
}
