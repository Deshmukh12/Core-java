package com.cg.employee;

public class Salesmanager extends Pemployee {
private int salesno,commission;

public Salesmanager() {
	super();
}
public Salesmanager(int employeeid, int basicSalary, String firstname, String lastname,int salesno) {
	super(employeeid, basicSalary, firstname, lastname);
	this.salesno=salesno;
}
public int getSalesno() {
	return salesno;
}
public void setSalesno(int salesno) {
	this.salesno = salesno;
}
public int getCommission() {
	return commission;
}
public void setCommission(int commission) {
	this.commission = commission;
}
public void salesDone() {
	System.out.println("its done");
}
@Override
public void calculateSalary() {
	commission=salesno*10;
	super.calculateSalary();
	this.setTotalSalary(getTotalSalary()+commission);
}
}
