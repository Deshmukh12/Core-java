package com.cg.employee;
public class Cemployee extends Employee {
private int variablepay,hrs;

public Cemployee() {
	super();
	// TODO Auto-generated constructor stub
}
public Cemployee(int employeeid, String firstname, String lastname,int hrs) {
	super(employeeid, firstname, lastname);
	this.hrs=hrs;
}
public Cemployee(int variablepay, int hrs) {
	super();
	this.variablepay = variablepay;
	this.hrs = hrs;
}
public int getVariablepay() {
	return variablepay;
}
public void setVariablepay(int variablepay) {
	this.variablepay = variablepay;
}
public int getHrs() {
	return hrs;
}
public void setHrs(int hrs) {
	this.hrs = hrs;
}
public void signContract() {
	System.out.println("contract has been sign");
}
public void calculateSalary(){
	this.variablepay=hrs*1000;
	this.setTotalSalary(hrs);
	}
}

