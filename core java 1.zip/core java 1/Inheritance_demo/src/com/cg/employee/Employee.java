package com.cg.employee;
public class Employee {
private int employeeid,basicSalary,totalSalary;
private String firstname,lastname;
public Employee() {
}
public Employee(int employeeid, String firstname, String lastname) {
	super();
	this.employeeid = employeeid;
	this.firstname = firstname;
	this.lastname = lastname;
}
public Employee(int employeeid, int basicSalary, String firstname, String lastname) {
	super();
	this.employeeid = employeeid;
	this.basicSalary = basicSalary;
	this.firstname = firstname;
	this.lastname = lastname;
}
public int getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(int employeeid) {
	this.employeeid = employeeid;
}
public int getBasicSalary() {
	return basicSalary;
}
public void setBasicSalary(int basicSalary) {
	this.basicSalary = basicSalary;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}

public int getTotalSalary() {
	return totalSalary;
}

public void setTotalSalary(int totalSalary) {
	this.totalSalary = totalSalary;
}
public void calculateSalary(){
	totalSalary=basicSalary;	
}
}
