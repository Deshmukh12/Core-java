package com.cg.client;

import com.cg.employee.Cemployee;
import com.cg.employee.Developer;
import com.cg.employee.Employee;
import com.cg.employee.Pemployee;
import com.cg.employee.Salesmanager;

public class MainClass {
	public static void main(String[] args) {
		Employee emp=new Employee(111,12000,"nikita","deshmukh");
		emp.calculateSalary();
		System.out.println(emp.getFirstname()+" "+emp.getLastname()+" "+emp.getTotalSalary());
		Cemployee cemp=new Cemployee(161,"nikita","deshmukh",12);
		cemp.calculateSalary();
		System.out.println(cemp.getFirstname()+" "+cemp.getLastname()+" "+cemp.getTotalSalary());
		Pemployee pemp=new Pemployee(191,112323,"monika","deshmukh");
		pemp.calculateSalary();
		System.out.println(pemp.getFirstname()+" "+pemp.getLastname()+" "+pemp.getTotalSalary());
		Developer demp=new Developer(191,112323,"monika","deshmukh",100);
		demp.calculateSalary();
		System.out.println(demp.getFirstname()+" "+demp.getLastname()+" "+demp.getTotalSalary()+" "+demp.getIntensive());
		Salesmanager semp=new Salesmanager(131,112323,"anjulatta","patil",100);
		semp.calculateSalary();
		System.out.println(semp.getFirstname()+" "+semp.getLastname()+" "+semp.getTotalSalary()+" "+semp.getCommission());
	}

}
