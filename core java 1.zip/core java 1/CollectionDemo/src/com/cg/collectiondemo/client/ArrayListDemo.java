package com.cg.collectiondemo.client;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListDemo {
public static  void ListDemo() {
	/*ArrayList<String> stList=new ArrayList<>();
	
	stList.add("nikita");
	stList.add("snehal");
	stList.add("mona");
	stList.add("pooja");
	
	System.out.println(stList);
	String name=stList.get(3);
	int idx=stList.indexOf("mona");
	String name2=stList.get(idx);
	System.out.println(name2);
 Collections.sort(stList);	*/
 
 ArrayList<Associate>associates=new ArrayList<>();
 associates.add(new Associate(1, "abc", "pqr", "200"));
 associates.add(new Associate(2, "abc", "pqr", "200"));
 associates.add(new Associate(3, "aabc", "pyr", "200"));

 Associate associateTobeSearch=new Associate(2, "abc", "pqr", "200");
 int idx=associates.indexOf(associateTobeSearch);
 System.out.println(idx);
 
 System.out.println(associates.remove(associateTobeSearch));
 
// Collections.sort(associates);
 
 Collections.sort(associates, new ComparaterAssociate());
 for (Associate associate : associates) {
	System.out.println(associate);
}

}
}
