package com.cg.collectiondemo.client;
@FunctionalInterface
public interface FctionalInterface2 {
boolean startWith(Associate associate);
}
