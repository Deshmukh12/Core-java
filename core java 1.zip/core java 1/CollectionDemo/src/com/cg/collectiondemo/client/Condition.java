package com.cg.collectiondemo.client;
@FunctionalInterface
public interface Condition {
boolean startWith(Associate associate);
}
