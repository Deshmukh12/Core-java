package com.cg.collectiondemo.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class MainClass {
	public static void main(String[] args) {
		//ArrayListDemo.ListDemo(); 
		ArrayList<Associate>associatesList=new ArrayList<>();
		associatesList.add(new Associate(1, "aman", "pqr", "200"));
		associatesList.add(new Associate(2, "bc", "pqr", "200"));
		 associatesList.add(new Associate(3, "arti", "pyr", "200"));
		 associatesList.add(new Associate(2, "bc", "pqr", "200"));
		 associatesList.add(new Associate(3, "pooja", "pyr", "200"));
		/* printEmployeeDetails1(associatesList, e->e.getFirstname().startsWith("a"));
		 printEmployeeDetails2(associatesList, e->e.getFirstname().startsWith("P"), e->System.out.println(e));*/

		 Stream<Associate>stream1=associatesList.stream();
		 Stream<Associate>stream2=stream1.distinct(); 
		 Stream<Associate>stream3=stream2.filter((associate)->associate.getFirstname().startsWith("a"));
		// System.out.println(stream3.count());
		 stream3.forEach(associate->System.out.println(associate));
		 
		 /*associatesList.stream().distinct().filter((associate)->associate.getFirstname().startsWith("a")).
		 forEach(associate->System.out.println(associate));;*/
		 
		 System.out.println(associatesList.stream().map(associate->associate.getBasicSalary()));
		// associatesList.forEach(e->System.out.println(e));//argu is of consumer type it is body of accept method
		     }
		 /*Comparator<Associate> associateomparator=( associate1, associate2)->associate1.getBasicSalary()-associate2.getBasicSalary();
		 Collections.sort(associates, associateomparator);*/
		//Collections.sort(associates, new ComparaterAssociate());
		// Collections.sort(associates,( associate1, associate2)->associate1.getBasicSalary()-associate2.getBasicSalary());
		 /*printAssociateDetails(associates,associate->associate.get)
		private static void printAssociateDetails(List<Associate>associates,Condition condition) {
			for (Associate associate : associates) {
				if(condition.startWith(associate))
			System.out.println(associate);
		}*/
		 /*@FunctionalInterface
		    public interface Condition<T> {
		        boolean startWith(T associates);
		    }
		    private static void printEmployeeDetails1(ArrayList<Associate>associateList , Condition<Associate> condition) {
		        for (Associate associate2 : associateList)
		            if(condition.startWith(associate2))
		                System.out.println(associate2);     
		    }
		    private static void printEmployeeDetails2(ArrayList<Associate>associateList ,Predicate<Associate>predicate, Consumer<Associate>consumer) {
		        for (Associate associate2 : associateList)
		            if(predicate.test(associate2))
		                consumer.accept(associate2);
		    }*/

		 
		}
		 

