package com.cg.collectiondemo.client;

import java.util.Comparator;

public class ComparaterAssociate implements Comparator<Associate>{

	@Override
	public int compare(Associate associate1, Associate associate2) {
		return associate1.Firstname.compareTo(associate2.Firstname);
		
	}

}
