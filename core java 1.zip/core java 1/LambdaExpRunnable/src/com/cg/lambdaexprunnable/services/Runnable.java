package com.cg.lambdaexprunnable.services;

public interface Runnable {

}
