package com.cg.lambdaexprunnable.client;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
