package com.cg.payroll.doaservices;
import java.util.HashSet;

import com.cg.payroll.beans.Associate;

public class AssociateDAOImpl implements AssociateDAO{

	@Override
	public Associate save(Associate associate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Associate associate) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Associate findOne(int associateID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashSet<Associate> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
