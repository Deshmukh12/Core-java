package com.cg.iodemo.beans;

import java.io.Serializable;

public class Associate implements Serializable{

	private int associateID;
transient private int basicSalary;
private String firstName,lastNamr;
public Associate() {
	// TODO Auto-generated constructor stub
}
public Associate(int associateID, int basicSalary, String firstName, String lastNamr) {
	super();
	this.associateID = associateID;
	this.basicSalary = basicSalary;
	this.firstName = firstName;
	this.lastNamr = lastNamr;
}
public int getAssociateID() {
	return associateID;
}
public void setAssociateID(int associateID) {
	this.associateID = associateID;
}
public int getBasicSalary() {
	return basicSalary;
}
public void setBasicSalary(int basicSalary) {
	this.basicSalary = basicSalary;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastNamr() {
	return lastNamr;
}
public void setLastNamr(String lastNamr) {
	this.lastNamr = lastNamr;
}
@Override
public String toString() {
	return "Associate [associateID=" + associateID + ", basicSalary=" + basicSalary + ", firstName=" + firstName
			+ ", lastNamr=" + lastNamr + "]";
}

}
