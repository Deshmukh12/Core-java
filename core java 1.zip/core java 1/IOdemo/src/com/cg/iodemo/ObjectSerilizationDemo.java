package com.cg.iodemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.iodemo.beans.Associate;

public class ObjectSerilizationDemo {
public static void doSerilization(File file) throws FileNotFoundException, IOException {
	Associate associate=new Associate(111,1999,"nikita", "deshmukh");
	try(ObjectOutputStream deStream=new ObjectOutputStream(new FileOutputStream(file))){
		deStream.writeObject(associate);
		System.out.println("associate obj written on :"+file.getAbsolutePath());
	}
}

public static void doDeSerilization(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
	//Associate associate=new Associate(111,1999,"nikita", "deshmukh");
	try(ObjectInputStream dInputStream=new ObjectInputStream(new FileInputStream(file))){
		Associate associate=(Associate)dInputStream.readObject();
		System.out.println("associate obj written on :"+file.getAbsolutePath());
		System.out.println(associate.toString());
	}
}
}
