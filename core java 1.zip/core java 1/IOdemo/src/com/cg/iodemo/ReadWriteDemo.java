package com.cg.iodemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadWriteDemo {
public static void byteReadWriteDemo(File fromFile,File toFile) throws FileNotFoundException, IOException {
	try(BufferedInputStream srcReader=new BufferedInputStream(new FileInputStream(fromFile))) {
		try(BufferedOutputStream destReader=new BufferedOutputStream(new FileOutputStream(toFile))){
			
			
			byte []bufferData=new byte[(int)fromFile.length()];
			srcReader.read(bufferData);
			destReader.write(bufferData);
			System.out.println("file written on"+toFile.getAbsolutePath());
		}
	}
}
public static void characterReadWriteDemo(File fromFile,File toFile) throws IOException {
	try(BufferedReader srReader=new BufferedReader(new FileReader(fromFile))){
		try(BufferedWriter srWriter=new BufferedWriter(new FileWriter(toFile))){
			String data="";
			while((data=srReader.readLine())!=null)
			{
				srWriter.write(data);
				System.out.println("file written on"+toFile.getAbsolutePath());
			}
		}
	}
}
}
