package com.cg.client;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import com.cg.iodemo.ObjectSerilizationDemo;
import com.cg.iodemo.ReadWriteDemo;
public class MainjClass {
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		File file=new File("D:\\abc.txt");
		//	ObjectSerilizationDemo.doSerilization(file);
		ObjectSerilizationDemo.doDeSerilization(file);
	}

}
