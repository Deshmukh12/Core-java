package com.cg.threaddemo.runs;

public class RunnableResource implements Runnable {

	@Override
	public void run() {
		try {
			Thread t=Thread.currentThread();
			int i = 1;
			if(t.getName().equals("th1")) {
				for( i=1;i<10;i++) {
				if(i%2==0)
				
						System.out.println("tick   "+i+" "+t.getName());
					}
				Thread.sleep(10000);
				}
			
				else if(t.getName().equals("th2")) {
					for(i=1;i<10;i++) {
						if(i%2!=0)
					System.out.println("tok   "+i+" "+t.getName());
				}
				}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	 
				
	}
}
				 
	
	

