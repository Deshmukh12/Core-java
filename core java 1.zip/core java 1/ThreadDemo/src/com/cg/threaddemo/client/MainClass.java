package com.cg.threaddemo.client;

import com.cg.threaddemo.runs.RunnableResource;

public class MainClass {

	public static void main(String[] args) {
	/*RunnableResource runnableResource=new RunnableResource();
	Thread th1=new Thread(runnableResource,"th1");
	th1.start();
	Thread th2=new Thread(runnableResource,"th2");
	th2.start();
*/	
new	Thread(()->{
	for(int i=1;i<10;i++)
		System.out.println("tick"+i);
} ).start();
}
	}

