package com.cg.payroll.client;
import java.io.FileNotFoundException;
import java.io.IOException;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.doaservices.AssociateDAO;
import com.cg.payroll.doaservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidEmailIdException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException, InvalidEmailIdException, AssociateDetailsNotFoundException {

		PayrollServices payrollServices=new PayrollServicesImpl();
		int associateID=payrollServices.acceptAssociateDetails(5000, "nikita", "deshmukh", "asf", "analyst", "vfgf222", "nikita@gmail.com", 50000,1000,1000, 123346578, 3333, "hdfc");
		System.out.println("AssociateID="+associateID);			
		int associateID1=payrollServices.acceptAssociateDetails(1000, "mayur", "deshmukh", "comp", "analyst", "vfgf222", "nikita@gmail.com", 50000,1000,1000, 123346578, 3333, "hdfc");

		System.out.println("AssociateID="+associateID1);
		//System.out.println(associate.toString());
		System.out.println(payrollServices.getAllAssociateDetaild());
		//Associate associate=payrollServices.getAssociateDetails(associateID1);
		//System.out.println(associate);
		int salary=payrollServices.calculateNetSalary(associateID);
		System.out.println(salary);
		/*AssociateDAO associateDAO=new AssociateDAOImpl();
		System.out.println(associateDAO.findAll());*/
	}

}


