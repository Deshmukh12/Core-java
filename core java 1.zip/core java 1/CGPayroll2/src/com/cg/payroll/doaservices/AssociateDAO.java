package com.cg.payroll.doaservices;
import java.util.HashSet;
import java.util.List;

import com.cg.payroll.beans.Associate;
public interface AssociateDAO {
	Associate save(Associate associate);
	boolean update(Associate associate);
	Associate findOne(int associateID);
	HashSet<Associate>findAll();
}

