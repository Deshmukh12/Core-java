package com.cg.payroll.doaservices;

import java.util.HashSet;

import java.util.Set;
import java.util.Iterator;


import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollUtil;
public class AssociateDAOImpl implements AssociateDAO{
	@Override
	public Associate save(Associate associate) {
		associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());
				PayrollUtil.associates.add(associate);
		return associate;
	}
	@Override
	public boolean update(Associate associate) {
		PayrollUtil.associates.add(associate);
		return true;
	}
	@Override
	public Associate findOne(int associateID) {
		Iterator<Associate>itr=PayrollUtil.associates.iterator();
			if(itr.next().getAssociateID()==associateID)
		return itr.next();
		return null;
	}
	@Override
	public HashSet<Associate> findAll() {
	
		return (HashSet<Associate>) PayrollUtil.associates;
	
	
	}
}
