package com.cg.payroll.services;
import java.util.HashSet;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.doaservices.AssociateDAO;
import com.cg.payroll.doaservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidEmailIdException;
public class PayrollServicesImpl implements PayrollServices {
	
	private AssociateDAO associateDAO;
	public PayrollServicesImpl() {
	assciateDAO=new AssociateDAOImpl();
	}
	
	
	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}


	private AssociateDAO assciateDAO=new AssociateDAOImpl();//here associatedao is member hence we take as a private
	@Override
	public int acceptAssociateDetails(int yearlyInvestmentUnder80c, String firstname, String lastname,
			String department, String designation, String pancard, String emailid,int basicSalary,int companypf,int epf,
			int accountno,int ifsccode,String bankname) throws InvalidEmailIdException{
		Associate associate=new Associate(yearlyInvestmentUnder80c, firstname, lastname, department, designation, pancard, emailid, new Salary(basicSalary, epf, companypf),new BankDetails(accountno, ifsccode, bankname));
		if(!associate.getEmailid().contains("@gmail.com"))
		 throw new InvalidEmailIdException();
		assciateDAO.save(associate);
		return associate.getAssociateID();
	}
	@Override
	public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException {
		Associate associate=this.getAssociateDetails(associateID);
		float monthlyTax,hra,conveyenceAllowance,otherAllowance,personalAllowance,grossSalary,netSalary,annualTax=0,taxableAmount,annualSalary;
		hra=(associate.getSalary().getBasicSalary()*40)/100;
		conveyenceAllowance=(associate.getSalary().getBasicSalary()*30)/100;
		otherAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		personalAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		grossSalary=associate.getSalary().getBasicSalary()+hra+conveyenceAllowance+personalAllowance+otherAllowance;
		annualSalary=grossSalary*12;
		taxableAmount=annualSalary-associate.getYearlyInvestmentUnder80c()-associate.getSalary().getEpf()*12-associate.getSalary().getCompanypf()*12;
		if(taxableAmount<250000)
			annualTax=0;
		if(taxableAmount>250000 && taxableAmount<=500000)
			annualTax=annualTax+((taxableAmount-250000)*10)/100;
		if(taxableAmount>500000 && taxableAmount<=1000000)
			annualTax=25000+((taxableAmount-500000)*20)/100;
		if(taxableAmount>1000000)
			annualTax=125000+((taxableAmount-1000000)*30)/100;
		monthlyTax=annualTax/12;
		netSalary=grossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanypf()-monthlyTax;
		return (int)netSalary;
	}
	@Override
	public Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException {
		Associate associate=assciateDAO.findOne(associateID);
		if(associate==null)throw new AssociateDetailsNotFoundException("associate details not found for associateid"+associateID);
		return associate;	//here it check associate is null then it returns null
	}
	@Override 
	public HashSet<Associate> getAllAssociateDetaild() {
		return (HashSet<Associate>) assciateDAO.findAll();
	}
}
