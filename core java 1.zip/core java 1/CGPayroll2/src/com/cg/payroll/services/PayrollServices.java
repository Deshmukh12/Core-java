package com.cg.payroll.services;
import java.util.HashSet;


import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidEmailIdException;
public interface PayrollServices {
	int acceptAssociateDetails(int yearlyInvestmentUnder80c, String firstname, String lastname,
			String department, String designation, String pancard, String emailid,int basicSalary,int companypf,int epf,
			int accountno,int ifsccode,String bankname)throws InvalidEmailIdException;
	int calculateNetSalary(int associateID)throws AssociateDetailsNotFoundException;
	Associate getAssociateDetails(int associateID)throws AssociateDetailsNotFoundException;
	HashSet<Associate> getAllAssociateDetaild();
}
