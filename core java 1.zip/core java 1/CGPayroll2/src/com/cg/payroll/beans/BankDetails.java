package com.cg.payroll.beans;

public class BankDetails {
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankDetails other = (BankDetails) obj;
		if (accountno != other.accountno)
			return false;
		if (bankname == null) {
			if (other.bankname != null)
				return false;
		} else if (!bankname.equals(other.bankname))
			return false;
		if (ifsccode != other.ifsccode)
			return false;
		return true;
	}
	private int accountno,ifsccode;
	private String bankname;
	public BankDetails() {
	}
	public BankDetails(int accountno, int ifsccode, String bankname) {
		super();
		this.accountno = accountno;
		this.ifsccode = ifsccode;
		this.bankname = bankname;
	}
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public int getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(int ifsccode) {
		this.ifsccode = ifsccode;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	@Override
	public String toString() {
		return "BankDetails [accountno=" + accountno + ", ifsccode=" + ifsccode + ", bankname=" + bankname + "]";
	}

}
