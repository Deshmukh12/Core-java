package com.cg.payroll.beans;
public class Associate {
	private int associateID,yearlyInvestmentUnder80c;
	private String Firstname,Lastname,department,designation,pancard,emailid;
	private Salary salary;
	private BankDetails bankDetails;
	Salary salary1=new  Salary();
	BankDetails bankdetails=new BankDetails();
	public Associate() {
	}
	public Associate(int yearlyInvestmentUnder80c, String firstname, String lastname, String department,
			String designation, String pancard, String emailid, Salary salary, BankDetails bankDetails) {
		super();
		this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
		Firstname = firstname;
		Lastname = lastname;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailid = emailid;
		this.salary = salary;
		this.bankDetails = bankDetails;
		/*this.salary1 = salary1;
		bankdetails = bankdetails2;*/
	}
	public Associate(int associateID, int yearlyInvestmentUnder80c, String firstname, String lastname,
			String department, String designation, String pancard, String emailid, Salary salary,
			BankDetails bankDetails) {
		super();
		this.associateID = associateID;
		this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
		Firstname = firstname;
		Lastname = lastname;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailid = emailid;
		this.salary = salary;
		this.bankDetails = bankDetails;
	}
	public int getAssociateID() {
		return associateID;
	}
	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}
	public int getYearlyInvestmentUnder80c() {
		return yearlyInvestmentUnder80c;
	}
	public void setYearlyInvestmentUnder80c(int yearlyInvestmentUnder80c) {
		this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (Firstname == null) {
			if (other.Firstname != null)
				return false;
		} else if (!Firstname.equals(other.Firstname))
			return false;
		if (Lastname == null) {
			if (other.Lastname != null)
				return false;
		} else if (!Lastname.equals(other.Lastname))
			return false;
		if (associateID != other.associateID)
			return false;
		if (bankDetails == null) {
			if (other.bankDetails != null)
				return false;
		} else if (!bankDetails.equals(other.bankDetails))
			return false;
		if (bankdetails == null) {
			if (other.bankdetails != null)
				return false;
		} else if (!bankdetails.equals(other.bankdetails))
			return false;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (emailid == null) {
			if (other.emailid != null)
				return false;
		} else if (!emailid.equals(other.emailid))
			return false;
		if (pancard == null) {
			if (other.pancard != null)
				return false;
		} else if (!pancard.equals(other.pancard))
			return false;
		if (salary == null) {
			if (other.salary != null)
				return false;
		} else if (!salary.equals(other.salary))
			return false;
		if (salary1 == null) {
			if (other.salary1 != null)
				return false;
		} else if (!salary1.equals(other.salary1))
			return false;
		if (yearlyInvestmentUnder80c != other.yearlyInvestmentUnder80c)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Associate [associateID=" + associateID + ", yearlyInvestmentUnder80c=" + yearlyInvestmentUnder80c
				+ ", Firstname=" + Firstname + ", Lastname=" + Lastname + ", department=" + department
				+ ", designation=" + designation + ", pancard=" + pancard + ", emailid=" + emailid + "]";
	}

}
