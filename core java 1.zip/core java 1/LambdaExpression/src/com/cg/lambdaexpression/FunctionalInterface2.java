package com.cg.lambdaexpression;

public interface FunctionalInterface2 {
int add(int a,int b);
}
