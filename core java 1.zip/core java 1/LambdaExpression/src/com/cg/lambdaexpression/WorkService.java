package com.cg.lambdaexpression;
@FunctionalInterface
public interface WorkService {
void doService();
}
