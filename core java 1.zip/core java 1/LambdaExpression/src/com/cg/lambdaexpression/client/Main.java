package com.cg.lambdaexpression.client;

import com.cg.lambdaexpression.FunctionalInterface1;
import com.cg.lambdaexpression.FunctionalInterface2;
import com.cg.lambdaexpression.FunctionalInterface3;
import com.cg.lambdaexpression.WorkService;

public class Main {

	public static void main(String[] args) {
		/*FunctionalInterface1 ref=(firstName,lastName)->System.out.println("good"+firstName+""+lastName);
			ref.greetUser("nikita", "deshmukh");*/
		
		/*FunctionalInterface2 ref2=(a,b)->a+b;
		System.out.println(ref2.add(2, 3));*/
		/*FunctionalInterface3 ref3=(str)->str.toUpperCase();
		System.out.println(ref3.toUpperCase("nikita"));*/
		callForWork(()->System.out.println("doing some work"));
	}
public static void callForWork(WorkService service) {
	service.doService();
}
}
