package com.cg.lambdaexpression;
@FunctionalInterface
public interface FunctionalInterface3 {
String toUpperCase(String str);
}
