package com.cg.lambdaexpression;
@FunctionalInterface
public interface FunctionalInterface1 {
void greetUser(String firstName,String lastName);
}
