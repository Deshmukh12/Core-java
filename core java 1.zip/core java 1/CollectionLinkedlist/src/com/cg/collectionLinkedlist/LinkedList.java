package com.cg.collectionLinkedlist;

import java.util.Collections;

public class LinkedList {
public static void linkedListDemo() {
     java.util.LinkedList<Associate> associates=new java.util.LinkedList<>();
	 associates.add(new Associate(1, "abc", "pqr", "200"));
	 associates.add(new Associate(2, "abc", "pqr", "200"));
	 associates.add(new Associate(3, "aabc", "pyr", "200"));

	 Associate associateTobeSearch=new Associate(2, "abc", "pqr", "200");
	 int idx=associates.indexOf(associateTobeSearch);
	 System.out.println(idx);
	 
	 System.out.println(associates.remove(associateTobeSearch));
	 
	// Collections.sort(associates);
	 
	 Collections.sort(associates, new ComparableAssociate());
	 for (Associate associate : associates) {
		System.out.println(associate);
	}
}
}
