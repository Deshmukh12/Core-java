package com.cg.collectionLinkedlist;

public class Associate {
	private int associateID;
	 String Firstname,Lastname,basicSalary;
	public Associate() {
}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (Firstname == null) {
			if (other.Firstname != null)
				return false;
		} else if (!Firstname.equals(other.Firstname))
			return false;
		if (Lastname == null) {
			if (other.Lastname != null)
				return false;
		} else if (!Lastname.equals(other.Lastname))
			return false;
		if (associateID != other.associateID)
			return false;
		if (basicSalary == null) {
			if (other.basicSalary != null)
				return false;
		} else if (!basicSalary.equals(other.basicSalary))
			return false;
		return true;
	}

	public Associate(int associateID, String firstname, String lastname, String basicSalary) {
		super();
		this.associateID = associateID;
		Firstname = firstname;
		Lastname = lastname;
		this.basicSalary = basicSalary;
	}
	public int getAssociateID() {
		return associateID;
	}
	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(String basicSalary) {
		this.basicSalary = basicSalary;
	}
	@Override
	public String toString() {
		return "Associate [associateID=" + associateID + ", Firstname=" + Firstname + ", Lastname=" + Lastname
				+ ", basicSalary=" + basicSalary + "]";
	}
	
}
