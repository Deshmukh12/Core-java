package com.cg.collectionLinkedlist;

import java.util.Comparator;

public class ComparableAssociate implements Comparator<Associate>{

	@Override
	public int compare(Associate associate1, Associate associate2) {
		
		return associate1.Firstname.compareTo(associate2.Firstname);
	}

}
