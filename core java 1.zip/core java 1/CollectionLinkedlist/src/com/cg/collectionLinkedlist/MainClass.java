package com.cg.collectionLinkedlist;

public class MainClass {

	public static void main(String[] args) {
	LinkedList.linkedListDemo();

	}

}
