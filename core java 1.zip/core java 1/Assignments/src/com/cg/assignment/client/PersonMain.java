package com.cg.assignment.client;
public class PersonMain {
	public static void main(String[] args) {
		Person person=new Person("Divya","bharani", 'F');
		System.out.println("Firstname:"+person.getFirstName()+"\n"+"Lastname:"+person.getLastName()+"\n"
				+"gender:"+person.getGender());

	}

}
