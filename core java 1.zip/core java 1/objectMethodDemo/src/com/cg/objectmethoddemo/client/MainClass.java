package com.cg.objectmethoddemo.client;
import com.cg.objectmethoddemo.beans.Associate;
public class MainClass {
	public static void main(String[] args) {
       int n=10;
       if(n==10)
    	   System.out.println("are equal");
       else
    	   System.out.println("not equal");
       Associate associate=new Associate(111,20000, "nikita", "deshmukh");
       Associate associate1=new Associate(111,20000, "nikita", "deshmukh");
       if(associate==(associate1))
    	   System.out.println("both reference are equal");
       else
    	   System.out.println("not equal");
       if(associate.equals(associate1))
    	   System.out.println("both reference are equal");
       else
    	   System.out.println("not equal");
	}

}
