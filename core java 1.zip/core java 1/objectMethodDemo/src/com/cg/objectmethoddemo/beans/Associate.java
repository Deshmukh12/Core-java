package com.cg.objectmethoddemo.beans;

public class Associate {
	private int associateID,basicSalary;
	private String firstName,lastName;
	private Address address;
	public Associate() {
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (associateID != other.associateID)
			return false;
		if (basicSalary != other.basicSalary)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		return true;
	}
	public Associate(int associateID, int basicSalary, String firstName, String lastName, Address address) {
		super();
		this.associateID = associateID;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}
	public Associate(int associateID, int basicSalary, String firstName, String lastName) {
		super();
		this.associateID = associateID;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getAssociateID() {
		return associateID;
	}
	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Associate [associateID=" + associateID + ", basicSalary=" + basicSalary + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", address=" + address + "]";
	}
}
