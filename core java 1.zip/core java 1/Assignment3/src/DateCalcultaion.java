

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
/*
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Minutes;
import org.joda.time.Seconds;*/

public class DateCalcultaion {



	  	public static void main(String[] args) {
	  		
	  	
	  	LocalDate startDate= LocalDate.of(2014, 01, 01);
	  	LocalDate now = LocalDate.now();
	  	 
	  	Period diff = Period.between(startDate, now);

	  	System.out.print("Difference is  years "+diff.getYears()+" months "+diff.getMonths()+" days "+diff.getDays());
	  }
	  }
  

