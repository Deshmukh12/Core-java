import java.util.Scanner;
public class Jobseeker {
	boolean validate(String username){		
		if(username.endsWith("_job") && username.length()>=12)
			return true;
					return false;
	}	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username ");
		String  username=sc.next();		
		Jobseeker jobseeker=new Jobseeker();
		System.out.println(jobseeker.validate(username));
	}
}
