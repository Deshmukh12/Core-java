import java.util.Arrays;
import java.util.Collections;
public class StringOrder {
	public static void main(String[] args) {
		String arr[] = {"pradnya", "nikita", "NIKHIL","SHUBHAM" }; 
		Arrays.sort(arr); 
		System.out.println("Modified arr[] "+
				Arrays.toString(arr)); 
	}
}
