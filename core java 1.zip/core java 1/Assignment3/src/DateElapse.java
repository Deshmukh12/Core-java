import java.beans.Customizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class DateElapse {
	public static void main(String[] args) {
		
	
	LocalDate startDate= LocalDate.of(2014, 01, 01);
	LocalDate endDate = LocalDate.of(2018, 02, 12);
	 
	Period diff = Period.between(startDate, endDate);

	System.out.print("Difference is  years "+diff.getYears()+" months "+diff.getMonths()+" days "+diff.getDays());
}
}