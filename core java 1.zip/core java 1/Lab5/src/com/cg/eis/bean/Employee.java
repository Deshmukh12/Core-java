package com.cg.eis.bean;
public class Employee {
private int employeeId,salary;
private String name, designation, insuranceScheme;
public Employee() {
}
public Employee(int employeeId, int salary, String name, String designation) {
	super();
	this.employeeId = employeeId;
	this.salary = salary;
	this.name = name;
	this.designation = designation;
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getInsuranceScheme() {
	return insuranceScheme;
}
public void setInsuranceScheme(String insuranceScheme) {
	this.insuranceScheme = insuranceScheme;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", salary=" + salary + ", name=" + name + ", designation="
			+ designation + ", insuranceScheme=" + insuranceScheme + "]";
}
}
