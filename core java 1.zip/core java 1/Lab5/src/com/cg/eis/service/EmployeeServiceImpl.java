package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	@Override
	public void calculateInsurance(int salary, String designation) {
		if(salary>50000 && designation=="analyst")
			System.out.println("Employee is illigible for health insurence");
		else if(salary>70000 && designation=="devloper")
			System.out.println("Employee is illigible for life insurence");
		else if(salary>100000 && designation=="manager")
			System.out.println("Employee is illigible for retirment insurence");
	}
	
	@Override
	public void addEmployeeDetails(int employeeId, int salary, String name, String designation) {
	
		
	}
	@Override
	public void getAllEmployeeDetails(int employeeId) {
		
		
	}

}
