package com.cg.eis.service;
public interface EmployeeService {
	void addEmployeeDetails(int employeeId, int salary, String name, String designation);
void getAllEmployeeDetails(int employeeId);
void calculateInsurance(int salary,String designation);

}
