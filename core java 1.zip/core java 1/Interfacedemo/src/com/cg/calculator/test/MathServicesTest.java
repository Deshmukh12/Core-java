package com.cg.calculator.test;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;//import should be proper
import org.junit.Test;
import com.cg.calculator.exception.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;
import org.junit.Assert;
public class MathServicesTest {  //take class as public we not take as public code willl not run
	private static MathServices mathServices;
	private int firstInvalidNumber,secondInvalidNumber,firstValidNumber,secondValidNumber;
	@BeforeClass
	public static void setUpTestEnv() {
		mathServices=new MathServicesImpl();
	}
	@Before
	public void setUpData() {
		firstInvalidNumber=-100;
		firstValidNumber=300;
		secondInvalidNumber=-200;
		secondValidNumber=200;
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.add(firstInvalidNumber, secondValidNumber);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.add(firstValidNumber, secondInvalidNumber);
	}
	@Test
	public void testAddForBothInvalidNumber()throws InvalidNumberRangeException{
		int expectedAns=500;
		int actualAns=mathServices.add(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.sub(firstInvalidNumber, secondValidNumber);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.sub(firstValidNumber, secondInvalidNumber);
	}
	@Test
	public void testSubForBothInvalidNumber()throws InvalidNumberRangeException{
		int expectedAns=100;
		int actualAns=mathServices.sub(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testMulForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.mul(firstInvalidNumber, secondValidNumber);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testMulForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.mul(firstValidNumber, secondInvalidNumber);
	}
	@Test
	public void testMulForBothInvalidNumber()throws InvalidNumberRangeException{
		int expectedAns=60000;
		int actualAns=mathServices.mul(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.div(firstInvalidNumber, secondValidNumber);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.div(firstValidNumber, secondInvalidNumber);
	}
	@Test
	public void testDivForBothInvalidNumber()throws InvalidNumberRangeException{
		int expectedAns=1;
		int actualAns=mathServices.div(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	@AfterClass
	public static void tearDownEnv() {
		mathServices=null;
	}
}
