package com.cg.calculator.client;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		int n1,n2;
		try {
			Scanner s=new Scanner(System.in);
			System.out.println("enter first no:");
			n1=s.nextInt();
			System.out.println("enter second no:");
			n2=s.nextInt();
			System.out.println(" ans:"+n1/n2);
		} catch (InputMismatchException e) {
			System.err.println("enter only numbers");
		}
		catch (ArithmeticException e) {
			System.err.println(e.getMessage()+" "+"enter second number");
		}
		catch (Exception e) {
			System.out.println("we cant doanything");
		}
		System.out.println("after catch");
	}
}
