package com.cg.calculator.client;

import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;

//import com.cg.calculator.services.MathServices;
//import com.cg.calculator.services.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
	/*	MathServices mathServices=new MathServicesImpl();
     System.out.println(mathServices.add(12, 12));
     System.out.println(mathServices.sub(12, 12));
     System.out.println(mathServices.div(12, 12));
     System.out.println(mathServices.mul (12,12));                
                                                                                                                                                                         
    */
     
	}

}
