package com.cg.payroll.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidEmailIdException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;


public class PayrollServiceTest {
	 /*static PayrollServices payrollservices;
	    @BeforeClass
	    public static void setUpTestEnv() {
	        payrollservices=new PayrollServicesImpl();
	    }
	    @Before
	    public void setUpTestData() {
	        Associate associate1=new Associate(101,5000, "nikita", "deshmukh", "asf", "analyst", "vfgf222", "nikita@gmail.com", new Salary(50000, 1000, 1000), new BankDetails(123346578, 3333, "hdfc"));
	        Associate associate2=new Associate(102,1000, "mayur", "deshmukh", "comp", "analyst", "vfgf222", "nikita@gmail.com", new Salary(50000, 1000, 1000), new BankDetails( 123346578, 3333, "hdfc"));
	        PayrollUtil.associates.put(associate1.getAssociateID(), associate1);
	        PayrollUtil.associates.put(associate2.getAssociateID(), associate2);
	        PayrollUtil.ASSOCIATE_ID_COUNTER=103;
	    }
	    @Test
	    public void testAcceptAssociateDataForValidData() throws InvalidEmailIdException {
	        int expectedAssociateId=103;
	        int actualAssociateId=payrollservices.acceptAssociateDetails(1000, "nmmm", "deshmukh", "asf", "analyst", "vfgf222", "nimm@gmail.com", 50000,1000,1000, 123346578, 3333, "hdfc");
	        Assert.assertEquals(expectedAssociateId, actualAssociateId);
	    }
	    @Test(expected=AssociateDetailsNotFoundException.class)
	    public void testAcceptAssociateDataForInvalidAssociateId()throws AssociateDetailsNotFoundException {
	        payrollservices.getAssociateDetails(222);
	    }
	    @Test
	    public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException{
	        Associate expectedAssociateId=new Associate(101, 5000, "nikita", "deshmukh", "asf", "analyst", "vfgf222", "nikita@gmail.com",new Salary(18000, 1000, 200),new BankDetails(51200125,15420, "hdfc12"));
	        Associate actualAssociateId=payrollservices.getAssociateDetails(101);
	        Assert.assertEquals(expectedAssociateId, actualAssociateId);
	    }
	    @Test(expected=AssociateDetailsNotFoundException.class)
	    public void testCalculateNetSalaryForInvalidAssociate() throws AssociateDetailsNotFoundException {
	        int actualNetSalary=payrollservices.calculateNetSalary(122);
	    }

	    @Test
	    public void testCalculateNetSalaryForValidAssociate() throws AssociateDetailsNotFoundException {
	        int expectedNetSalary=86808;
	        int actualNetSalary=payrollservices.calculateNetSalary(101);
	        Assert.assertEquals(expectedNetSalary, actualNetSalary);    
	    }

	    @Test
	    public void testGetAllDetailsForValidAssociate() {
	        ArrayList<Associate> expectedAllDetails=new ArrayList<>();
	        expectedAllDetails.add(new Associate(101,6000, "priya", "kapase", "IT", "analyst", "FHA612GF","ps@gmail.com",  new Salary(6000, 1500, 1200), new BankDetails(123346578, 3333, "hdfc")));
	        expectedAllDetails.add(new Associate(101,6000, "priya", "kapase", "IT", "analyst", "FHA612GF", "ps@gmail.com",  new Salary(6000, 1500, 1200), new BankDetails(98656, 62532, "hdfc")));
	        ArrayList<Associate>actualAllDetails=expectedAllDetails;
	        Assert.assertEquals(expectedAllDetails, actualAllDetails);
	    }
	    @After
	    public void tearDownTestData() {
	        PayrollUtil.ASSOCIATE_ID_COUNTER=100;
	        PayrollUtil.associates.clear();
	    }

	    @AfterClass
	    public static void tearDownTestEnv() {
	        payrollservices=null;
	    }
*/
}
