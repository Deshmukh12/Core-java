package com.cg.bank.daoservices;

import java.util.List;

import com.cg.bank.customer.Customer;

public interface CustomerDao {
	Customer save(Customer customer);
	boolean update(Customer customer);
	Customer findOne(int customerID);
	List<Customer> findAll();
}
