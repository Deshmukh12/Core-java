package com.cg.bank.test;



import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.bank.customer.Account;
import com.cg.bank.customer.Customer;
import com.cg.bank.customernotfoundexception.CustomerNotFoundException;
import com.cg.bank.services.BankService;
import com.cg.bank.services.BankServicesImpl;
import com.cg.bank.util.BankUtil;

class BankServiceTest {
	static BankService bankService;
	@Before
	public static void setUpTestEnv() {
		bankService=new BankServicesImpl();
	}
	@Before
	public void setUpData1() {
		Customer customer=new Customer(101, 566265, 6565, 120121, "pradnya", "shinde", "ps@gmail.com", "yghbghy44", new Account(5745, 200, "savving"));
		
		Customer customer2=new Customer(102, 566265, 6565, 120121, "pradnya", "shinde", "ps@gmail.com", "yghbghy44", new Account(5745, 200, "savving"));
		BankUtil.customers.put(customer.getCustomerID(),customer);
		BankUtil.customers.put(customer2.getCustomerID(),customer);
	}
	@Test
	public void testAcceptCustomerDetailsForValidData() {
		int expectedCustomerID=103;
		int actualCustomerId=bankService.acceptCustomerDetails(103, 1234, 2345,124357, "nikita","deshmukh", "niki@gmail.com", "esc245","shirpur","mh", "in",1234, 
29000, "saving");
		Assert.assertEquals(expectedCustomerID, actualCustomerId);
		
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerDataForInvalidAssociateID() throws CustomerNotFoundException {
		bankService.getCustomerDetails(200);
	}
	
	@After
	public void tearDownTestData() {
		BankUtil.CUSTOMER_ID_COUNTER=100;
		BankUtil.customers.clear();
	}
	@After
	public static void tearDownTestEnv() {
		bankService=null;
	}
	

}
