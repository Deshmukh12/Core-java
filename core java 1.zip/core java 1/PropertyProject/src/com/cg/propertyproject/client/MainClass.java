package com.cg.propertyproject.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class MainClass {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		try {
			Properties properties=new Properties();
			properties.load(new  FileInputStream(".\\resources\\project.properties"));
			String var1=properties.getProperty("key1");
			System.out.println(var1);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
