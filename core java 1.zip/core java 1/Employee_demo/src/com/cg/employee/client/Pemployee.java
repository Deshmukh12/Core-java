package com.cg.employee.client;

public class Pemployee extends Employee{
private int hra,da,ta;

public Pemployee() {
	super();
}
public Pemployee(int employeeid, int totalsalary, int basicsalary, String firstname, String lastname) {
	super(employeeid, totalsalary, basicsalary, firstname, lastname);
	// TODO Auto-generated constructor stub
}
public Pemployee(int hra, int da, int ta) {
	super();
	this.hra = hra;
	this.da = da;
	this.ta = ta;
}
public int getHra() {
	return hra;
}
public void setHra(int hra) {
	this.hra = hra;
}
public int getDa() {
	return da;
}
public void setDa(int da) {
	this.da = da;
}
public int getTa() {
	return ta;
}
public void setTa(int ta) {
	this.ta = ta;
}
public void perMant() {
	System.out.println("permanant employee");
}
public void calCulatesalary() {
	hra=this.getBasicsalary()*10/100;
	ta=this.getBasicsalary()*10/100;
	da=this.getBasicsalary()*10/100;
	this.setTotalsalary(this.getBasicsalary()+hra+da+ta);
}
@Override
public String toString() {
	return super.toString()+" hra=" + hra + ", da=" + da + ", ta=" + ta + "";
}




}
