package com.cg.employee.client;

public final class Developer extends Pemployee{
private int intencive,noofprojects;

public Developer() {
	super();
	// TODO Auto-generated constructor stub
}

public Developer(int employeeid, int totalsalary, int basicsalary, String firstname, String lastname,int noofprojects) {
	super(employeeid, totalsalary, basicsalary, firstname, lastname);
	this.noofprojects=noofprojects;
}

public int getIntencive() {
	return intencive;
}

public void setIntencive(int intencive) {
	this.intencive = intencive;
}

public int getNoofprojects() {
	return noofprojects;
}

public void setNoofprojects(int noofprojects) {
	this.noofprojects = noofprojects;
}
public void developed() {
	System.out.println("project is ready");
}
@Override
public void calCulatesalary() {
	intencive=noofprojects*1000;
	super.calCulatesalary();
	this.setTotalsalary(getBasicsalary()+intencive);
}

}
