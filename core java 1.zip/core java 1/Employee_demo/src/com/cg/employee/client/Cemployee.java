package com.cg.employee.client;

public final class Cemployee extends Employee{
	private int variablpay,hrs;

	public Cemployee() {
		super();
	}
	public Cemployee(int employeeid, String firstname, String lastname,int hrs) {
		super(employeeid, firstname, lastname);
		this.hrs=hrs;
	}
	public Cemployee(int variablpay, int hrs) {
		super();
		this.variablpay = variablpay;
		this.hrs = hrs;
	}
	public int getVariablpay() {
		return variablpay;
	}
	public void setVariablpay(int variablpay) {
		this.variablpay = variablpay;
	}
	public int getHrs() {
		return hrs;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public void signcontract() {
		System.out.println("contract has sign");
	}
	public void calCulatesalary() {
		this.variablpay=hrs*1000;
		this.setTotalsalary(hrs);
	}
	@Override
	public String toString() {
		return super.toString()+" [variablpay=" + variablpay + ", hrs=" + hrs + "]";
	}
	
}
