package com.cg.employee.client;

public abstract class Employee {
private int employeeid,totalsalary,basicsalary;
private String firstname,lastname;
public Employee() {
}
public Employee(int employeeid, String firstname, String lastname) {
	super();
	this.employeeid = employeeid;
	this.firstname = firstname;
	this.lastname = lastname;
}
public Employee(int employeeid, int totalsalary, int basicsalary, String firstname, String lastname) {
	super();
	this.employeeid = employeeid;
	this.totalsalary = totalsalary;
	this.basicsalary = basicsalary;
	this.firstname = firstname;
	this.lastname = lastname;
}
public int getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(int employeeid) {
	this.employeeid = employeeid;
}
public int getTotalsalary() {
	return totalsalary;
}
public void setTotalsalary(int totalsalary) {
	this.totalsalary = totalsalary;
}
public int getBasicsalary() {
	return basicsalary;
}
public void setBasicsalary(int basicsalary) {
	this.basicsalary = basicsalary;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public abstract void calCulatesalary();
@Override
public String toString() {
	return "employeeid=" + employeeid + ", totalsalary=" + totalsalary + ", basicsalary=" + basicsalary
			+ ", firstname=" + firstname + ", lastname=" + lastname + "";
}

}
