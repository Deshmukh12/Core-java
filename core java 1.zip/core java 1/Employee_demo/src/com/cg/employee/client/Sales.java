package com.cg.employee.client;

public final class Sales extends Pemployee{
private int salesno,commission;

public Sales() {
	super();
	// TODO Auto-generated constructor stub
}

public Sales(int employeeid, int totalsalary, int basicsalary, String firstname, String lastname,int salesno) {
	super(employeeid, totalsalary, basicsalary, firstname, lastname);
	this.salesno=salesno;
}

public int getSalesno() {
	return salesno;
}

public void setSalesno(int salesno) {
	this.salesno = salesno;
}

public int getCommission() {
	return commission;
}

public void setCommission(int commission) {
	this.commission = commission;
}
public void salesaredone() {
	System.out.println("sales are dones");
}
@Override
public void calCulatesalary() {
	commission=salesno*10;
	super.calCulatesalary();
	this.setTotalsalary(getTotalsalary()+commission);
}

}
