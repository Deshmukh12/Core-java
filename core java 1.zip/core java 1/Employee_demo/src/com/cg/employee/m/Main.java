package com.cg.employee.m;

import com.cg.employee.client.Cemployee;
import com.cg.employee.client.Developer;
import com.cg.employee.client.Employee;
import com.cg.employee.client.Pemployee;
import com.cg.employee.client.Sales;

public class Main {

	public static void main(String[] args) {
		/*Employee emp=new Employee(111,12000,111111,"nikita","deshmukh");
		emp.calCulatesalary();
		System.out.println(emp.getFirstname()+" "+emp.getLastname()+" "+emp.getTotalsalary());
		Pemployee pemp=new Pemployee(111,12000,111111,"snehal","deshmukh");
		pemp.calCulatesalary();
		System.out.println(pemp.getFirstname()+" "+pemp.getLastname()+" "+pemp.getTotalsalary()+" "+pemp.getBasicsalary());
		Cemployee cemp=new Cemployee(111,"pooja","deshmukh",67);
		cemp.calCulatesalary();
		System.out.println(cemp.getFirstname()+" "+cemp.getLastname()+" "+cemp.getHrs()+" "+cemp.getEmployeeid());
		Developer demp=new Developer(111,12000,111111,"sidhi","deshmukh",10);
		demp.calCulatesalary();
		System.out.println(demp.getFirstname()+" "+demp.getLastname()+" "+demp.getTotalsalary()+" "+demp.getBasicsalary());//USING STATIC BINDING
		Sales semp=new Sales(111,12000,111111,"lalita","patil",10);
		semp.calCulatesalary();
		System.out.println(semp.getFirstname()+" "+semp.getLastname()+" "+semp.getTotalsalary()+" "+semp.getBasicsalary()+" "+semp.getSalesno());*/
		Employee emp;
		/*emp=new Employee(111,12000,111111,"nikita","deshmukh");
		emp.calCulatesalary();
		System.out.println(emp.getFirstname()+" "+emp.getLastname()+" "+emp.getTotalsalary());*/
		
		emp=new Pemployee(111,12000,111111,"snehal","deshmukh");
		Pemployee pmp=(Pemployee)emp;
		pmp.perMant();
		emp.calCulatesalary();
		System.out.println(emp.toString());
		
		emp=new Cemployee(111,"pooja","deshmukh",67);
		Cemployee cemp=(Cemployee)emp;
		cemp.signcontract();
		emp.calCulatesalary();
		System.out.println(emp.getFirstname()+" "+emp.getLastname()+" "+emp.getEmployeeid());//USING DYANAMIC BINDING
	
	  emp=new Developer(111,12000,111111,"sidhi","deshmukh",10);
	  Developer dev=(Developer)emp;
	  dev.developed();
		emp.calCulatesalary();
		System.out.println(emp.getFirstname()+" "+emp.getLastname()+" "+emp.getTotalsalary()+" "+emp.getBasicsalary());
	
	emp=new Sales(111,12000,111111,"lalita","patil",10);//upcasting(child to parent conversion)
	Sales sal=(Sales)emp;//downcasting (parent to child)
	sal.salesaredone();
	emp.calCulatesalary();
	System.out.println(emp.getFirstname()+" "+emp.getLastname()+" "+emp.getTotalsalary()+" "+emp.getBasicsalary());
	}

}
